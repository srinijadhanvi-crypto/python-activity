# Case Study 37: Monthly Calendar Generator

## Problem statement
Generate a calendar using a supplied first weekday and number of days.

## Objectives
- Apply computational thinking and the prescribed Python fundamentals to the problem.
- Validate data, compute results, and display understandable outcomes.

## Assumptions and rules
Week starts Monday (0) through Sunday (6). Day count must be 28, 29, 30 or 31; the user supplies the valid combination for the intended month and year.

## Algorithm
1. Validate first weekday and month length.
2. Print the weekday heading and initial padding.
3. Print each day in a fixed-width field, breaking after Sunday.
4. Reject invalid calendar settings.

## Flowchart
```mermaid
flowchart TD
    S([Start]) --> A
    A["Validate first weekday and month length."] --> N1
    N1["Print the weekday heading and initial padding."] --> N2
    N2["Print each day in a fixed-width field, breaking after Sunday."] --> N3
    N3["Reject invalid calendar settings."] --> Z
    Z([End])
```

**Text equivalent:** Start → Validate first weekday and month length. → Print the weekday heading and initial padding. → Print each day in a fixed-width field, breaking after Sunday. → Reject invalid calendar settings. → End.

## Pseudocode
```text
BEGIN
1. Validate first weekday and month length.
2. Print the weekday heading and initial padding.
3. Print each day in a fixed-width field, breaking after Sunday.
4. Reject invalid calendar settings.
END
```

## Python source code
See [`solution.py`](solution.py). The sample inputs are defined near the top of the file; edit them to try other scenarios. Run `python solution.py`.

## Test cases
- start 2, 30 days → day 1 under Wednesday
- start 6, 28 days → day 1 under Sunday
- start 7 → invalid
- 27 days → invalid

The included program runs these examples. Actual console output is in [`output.txt`](output.txt); the image below is rendered directly from that output.

## Output screenshot
![Program output](output.png)

## Conclusion
The solution applies the stated rules to the supplied examples and reports results and validation outcomes. Its conclusions are specific to the assumptions above; change those rules if a different policy is required.
