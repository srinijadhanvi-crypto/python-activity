# Case Study 13: ATM Transaction Sequence

## Problem statement
Simulate deposits and withdrawals and report accepted and rejected operations.

## Objectives
- Apply computational thinking and the prescribed Python fundamentals to the problem.
- Validate data, compute results, and display understandable outcomes.

## Assumptions and rules
Opening balance is ₹1,000; each withdrawal is limited to ₹500; amounts must be positive and withdrawals cannot exceed the balance. Unsupported transaction types are rejected.

## Algorithm
1. Set opening balance and counters.
2. Inspect each transaction and validate its type and amount.
3. Update the balance only for valid deposits or withdrawals.
4. Print each decision and summarize accepted and rejected transactions.

## Flowchart
```mermaid
flowchart TD
    S([Start]) --> A
    A["Set opening balance and counters."] --> N1
    N1["Inspect each transaction and validate its type and amount."] --> N2
    N2["Update the balance only for valid deposits or withdrawals."] --> N3
    N3["Print each decision and summarize accepted and rejected transactions."] --> Z
    Z([End])
```

**Text equivalent:** Start → Set opening balance and counters. → Inspect each transaction and validate its type and amount. → Update the balance only for valid deposits or withdrawals. → Print each decision and summarize accepted and rejected transactions. → End.

## Pseudocode
```text
BEGIN
1. Set opening balance and counters.
2. Inspect each transaction and validate its type and amount.
3. Update the balance only for valid deposits or withdrawals.
4. Print each decision and summarize accepted and rejected transactions.
END
```

## Python source code
See [`solution.py`](solution.py). The sample inputs are defined near the top of the file; edit them to try other scenarios. Run `python solution.py`.

## Test cases
- Deposit 250 → balance 1250
- Withdraw 400 → balance 850
- Withdraw 600 → rejected (limit)
- Deposit -10 and transfer → rejected
- Withdraw 500 → final balance 350

The included program runs these examples. Actual console output is in [`output.txt`](output.txt); the image below is rendered directly from that output.

## Output screenshot
![Program output](output.png)

## Conclusion
The solution applies the stated rules to the supplied examples and reports results and validation outcomes. Its conclusions are specific to the assumptions above; change those rules if a different policy is required.
