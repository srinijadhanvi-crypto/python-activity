# Case Study 12: Attendance Recovery

## Problem statement
Find the minimum consecutive attended classes needed to reach a target, including future missed classes.

## Objectives
- Apply computational thinking and the prescribed Python fundamentals to the problem.
- Validate data, compute results, and display understandable outcomes.

## Assumptions and rules
Total classes must be positive; attended cannot exceed total; target must be between 0 and 100. The scenario specifies missed classes before recovery. A target of 100% cannot be recovered after any absence.

## Algorithm
1. Validate attendance, target and future missed classes.
2. Add the future missed classes to total classes.
3. If target is already met, return zero; if 100% is unattainable, report impossible.
4. Attend one class at a time until the threshold is met.

## Flowchart
```mermaid
flowchart TD
    S([Start]) --> A
    A["Validate attendance, target and future missed classes."] --> N1
    N1["Add the future missed classes to total classes."] --> N2
    N2["If target is already met, return zero; if 100% is unattainable, report impossible."] --> N3
    N3["Attend one class at a time until the threshold is met."] --> Z
    Z([End])
```

**Text equivalent:** Start → Validate attendance, target and future missed classes. → Add the future missed classes to total classes. → If target is already met, return zero; if 100% is unattainable, report impossible. → Attend one class at a time until the threshold is met. → End.

## Pseudocode
```text
BEGIN
1. Validate attendance, target and future missed classes.
2. Add the future missed classes to total classes.
3. If target is already met, return zero; if 100% is unattainable, report impossible.
4. Attend one class at a time until the threshold is met.
END
```

## Python source code
See [`solution.py`](solution.py). The sample inputs are defined near the top of the file; edit them to try other scenarios. Run `python solution.py`.

## Test cases
- (60, 80, 75, 0) → 0 classes
- (60, 80, 75, 5) → 15 classes
- (9, 10, 100, 0) → impossible
- (10, 10, 100, 0) → 0 classes
- (8, 0, 75, 0) → invalid

The included program runs these examples. Actual console output is in [`output.txt`](output.txt); the image below is rendered directly from that output.

## Output screenshot
![Program output](output.png)

## Conclusion
The solution applies the stated rules to the supplied examples and reports results and validation outcomes. Its conclusions are specific to the assumptions above; change those rules if a different policy is required.
